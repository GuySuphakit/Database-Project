--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE moviereservation;
--
-- Name: moviereservation; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE moviereservation WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE moviereservation OWNER TO postgres;

\connect moviereservation

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cinema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cinema (
    cinemaid integer NOT NULL,
    name text,
    seatno integer
);


ALTER TABLE public.cinema OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customerid text NOT NULL,
    fname text,
    lname text,
    email text,
    gender text,
    password text,
    mobile text,
    membership boolean,
    age integer
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: genre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genre (
    genreid text NOT NULL,
    descr text
);


ALTER TABLE public.genre OWNER TO postgres;

--
-- Name: movie; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movie (
    movieid text NOT NULL,
    title text,
    duration integer,
    rate text,
    language text,
    subtitle text
);


ALTER TABLE public.movie OWNER TO postgres;

--
-- Name: moviegenre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moviegenre (
    movieid text,
    genreid text
);


ALTER TABLE public.moviegenre OWNER TO postgres;

--
-- Name: movieshowdate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movieshowdate (
    movieshowdateid integer NOT NULL,
    movieid text,
    datestart date,
    dateend date
);


ALTER TABLE public.movieshowdate OWNER TO postgres;

--
-- Name: reservation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservation (
    reservationid integer NOT NULL,
    customerid text,
    showtimeid integer,
    payment text,
    total integer,
    discount integer,
    netpay integer,
    vat numeric(8,2),
    reservationtypeid integer
);


ALTER TABLE public.reservation OWNER TO postgres;

--
-- Name: reservationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservationtype (
    reservationtypeid integer NOT NULL,
    type text
);


ALTER TABLE public.reservationtype OWNER TO postgres;

--
-- Name: seatreserved; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seatreserved (
    seatreservedid integer NOT NULL,
    reservationid integer,
    seatid integer
);


ALTER TABLE public.seatreserved OWNER TO postgres;

--
-- Name: seats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.seats (
    seatid integer NOT NULL,
    cinemaid integer,
    seat text
);


ALTER TABLE public.seats OWNER TO postgres;

--
-- Name: showtimes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.showtimes (
    showtimeid integer NOT NULL,
    movieshowdateid integer,
    showtime time without time zone,
    cinemaid integer
);


ALTER TABLE public.showtimes OWNER TO postgres;

--
-- Data for Name: cinema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cinema (cinemaid, name, seatno) FROM stdin;
\.
COPY public.cinema (cinemaid, name, seatno) FROM '$$PATH$$/3210.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customerid, fname, lname, email, gender, password, mobile, membership, age) FROM stdin;
\.
COPY public.customer (customerid, fname, lname, email, gender, password, mobile, membership, age) FROM '$$PATH$$/3211.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genre (genreid, descr) FROM stdin;
\.
COPY public.genre (genreid, descr) FROM '$$PATH$$/3212.dat';

--
-- Data for Name: movie; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movie (movieid, title, duration, rate, language, subtitle) FROM stdin;
\.
COPY public.movie (movieid, title, duration, rate, language, subtitle) FROM '$$PATH$$/3213.dat';

--
-- Data for Name: moviegenre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moviegenre (movieid, genreid) FROM stdin;
\.
COPY public.moviegenre (movieid, genreid) FROM '$$PATH$$/3214.dat';

--
-- Data for Name: movieshowdate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movieshowdate (movieshowdateid, movieid, datestart, dateend) FROM stdin;
\.
COPY public.movieshowdate (movieshowdateid, movieid, datestart, dateend) FROM '$$PATH$$/3215.dat';

--
-- Data for Name: reservation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservation (reservationid, customerid, showtimeid, payment, total, discount, netpay, vat, reservationtypeid) FROM stdin;
\.
COPY public.reservation (reservationid, customerid, showtimeid, payment, total, discount, netpay, vat, reservationtypeid) FROM '$$PATH$$/3216.dat';

--
-- Data for Name: reservationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservationtype (reservationtypeid, type) FROM stdin;
\.
COPY public.reservationtype (reservationtypeid, type) FROM '$$PATH$$/3217.dat';

--
-- Data for Name: seatreserved; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seatreserved (seatreservedid, reservationid, seatid) FROM stdin;
\.
COPY public.seatreserved (seatreservedid, reservationid, seatid) FROM '$$PATH$$/3218.dat';

--
-- Data for Name: seats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.seats (seatid, cinemaid, seat) FROM stdin;
\.
COPY public.seats (seatid, cinemaid, seat) FROM '$$PATH$$/3219.dat';

--
-- Data for Name: showtimes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.showtimes (showtimeid, movieshowdateid, showtime, cinemaid) FROM stdin;
\.
COPY public.showtimes (showtimeid, movieshowdateid, showtime, cinemaid) FROM '$$PATH$$/3220.dat';

--
-- Name: cinema Cinema_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cinema
    ADD CONSTRAINT "Cinema_pkey" PRIMARY KEY (cinemaid);


--
-- Name: customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (customerid);


--
-- Name: genre Genre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genre
    ADD CONSTRAINT "Genre_pkey" PRIMARY KEY (genreid);


--
-- Name: movieshowdate MovieShowDate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movieshowdate
    ADD CONSTRAINT "MovieShowDate_pkey" PRIMARY KEY (movieshowdateid);


--
-- Name: movie Movie_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movie
    ADD CONSTRAINT "Movie_pkey" PRIMARY KEY (movieid);


--
-- Name: reservationtype ReservationType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservationtype
    ADD CONSTRAINT "ReservationType_pkey" PRIMARY KEY (reservationtypeid);


--
-- Name: reservation Reservation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT "Reservation_pkey" PRIMARY KEY (reservationid);


--
-- Name: seatreserved SeatReserved_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seatreserved
    ADD CONSTRAINT "SeatReserved_pkey" PRIMARY KEY (seatreservedid);


--
-- Name: seats Seats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seats
    ADD CONSTRAINT "Seats_pkey" PRIMARY KEY (seatid);


--
-- Name: showtimes Showtimes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.showtimes
    ADD CONSTRAINT "Showtimes_pkey" PRIMARY KEY (showtimeid);


--
-- Name: moviegenre MovieGenre_Genre_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moviegenre
    ADD CONSTRAINT "MovieGenre_Genre_fk" FOREIGN KEY (genreid) REFERENCES public.genre(genreid) NOT VALID;


--
-- Name: moviegenre MovieGenre_Movie_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moviegenre
    ADD CONSTRAINT "MovieGenre_Movie_fk" FOREIGN KEY (movieid) REFERENCES public.movie(movieid) NOT VALID;


--
-- Name: movieshowdate MovieShowDate_Movie_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movieshowdate
    ADD CONSTRAINT "MovieShowDate_Movie_fk" FOREIGN KEY (movieid) REFERENCES public.movie(movieid) NOT VALID;


--
-- Name: reservation Reservation_Customer_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT "Reservation_Customer_fk" FOREIGN KEY (customerid) REFERENCES public.customer(customerid) NOT VALID;


--
-- Name: reservation Reservation_ReservationType_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT "Reservation_ReservationType_fk" FOREIGN KEY (reservationtypeid) REFERENCES public.reservationtype(reservationtypeid) NOT VALID;


--
-- Name: reservation Reservation_Showtimes_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation
    ADD CONSTRAINT "Reservation_Showtimes_fk" FOREIGN KEY (showtimeid) REFERENCES public.showtimes(showtimeid) NOT VALID;


--
-- Name: seatreserved SeatReserved_Reservation_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seatreserved
    ADD CONSTRAINT "SeatReserved_Reservation_fk" FOREIGN KEY (reservationid) REFERENCES public.reservation(reservationid) NOT VALID;


--
-- Name: seatreserved SeatReserved_Seats_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seatreserved
    ADD CONSTRAINT "SeatReserved_Seats_fk" FOREIGN KEY (seatid) REFERENCES public.seats(seatid) NOT VALID;


--
-- Name: seats Seats_Cinema_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.seats
    ADD CONSTRAINT "Seats_Cinema_fk" FOREIGN KEY (cinemaid) REFERENCES public.cinema(cinemaid) NOT VALID;


--
-- Name: showtimes Showtimes_Cinema_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.showtimes
    ADD CONSTRAINT "Showtimes_Cinema_fk" FOREIGN KEY (cinemaid) REFERENCES public.cinema(cinemaid) NOT VALID;


--
-- Name: showtimes Showtimes_MovieShowDate_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.showtimes
    ADD CONSTRAINT "Showtimes_MovieShowDate_fk" FOREIGN KEY (movieshowdateid) REFERENCES public.movieshowdate(movieshowdateid) NOT VALID;


--
-- PostgreSQL database dump complete
--

